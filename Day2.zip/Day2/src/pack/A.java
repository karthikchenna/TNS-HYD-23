package pack;

public class A {
	public void msg() {
		System.out.println("Hello!, from package 'pack' class A");
	}
}
