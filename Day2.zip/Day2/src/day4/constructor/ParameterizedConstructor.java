package day4.constructor;

public class ParameterizedConstructor {
	int number;
	
	ParameterizedConstructor(int n) {
		number = n;
	}
	
	public static void main(String[] args) {
		ParameterizedConstructor p1 = new ParameterizedConstructor(44);
		System.out.println(p1.number);	
	}

}
