package day4.constructor;

public class DefaultConstructor {
	int number;
	
	DefaultConstructor() {
		number = 69;
	}
	
	public static void main(String[] args) {
		DefaultConstructor d1 = new DefaultConstructor();
		System.out.println(d1.number);
		
	}

}
