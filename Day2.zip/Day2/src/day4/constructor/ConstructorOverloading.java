package day4.constructor;

public class ConstructorOverloading {
	String name;
	String branch;
	int id;
	
	ConstructorOverloading(){
		name = "This is a Default Name";
		branch = "CSE";
		id = 1;		
	}
	
	ConstructorOverloading(String x, String y) {
		name = x;
		branch = y;
	}
	
	ConstructorOverloading(String x, String y, int z) {
		name = x;
		branch = y;
		id = z;
	}
	
	public void printResult() {
		System.out.println(name +"\n" + branch + "\n" + id);
	}
	
	public static void main(String[] args) {
		ConstructorOverloading c1 = new ConstructorOverloading();
		System.out.println("This is a Default Constructor");
		c1.printResult();
		
		ConstructorOverloading c2 = new ConstructorOverloading("Karthik", "IT");
		System.out.println("This is Parameterised construcor with 2 arguments");
		c2.printResult();

		ConstructorOverloading c3 = new ConstructorOverloading("Banti", "Mech", 1234);
		System.out.println("This is Parameterised construcor with 3 arguments");
		c3.printResult();
		
	}

}
