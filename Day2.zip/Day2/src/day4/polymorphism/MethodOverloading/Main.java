package day4.polymorphism.MethodOverloading;

public class Main {
	
	String name = "Default";
	int age = 12;
	
	void printDetails() {
		System.out.println("Employee Name :" + name);
	}
	
	void printDetails(String str) {
		name = str;
		System.out.println("Employee Name :" + name);
	}
	
	void printDetails(String str, int n) {
		name = str;
		age = n;
		System.out.println("Employee Name :" + name + "Age: " + age);
	}

	public static void main(String[] args) {
		Main m1 = new Main();
		
		m1.printDetails();
		
		m1.printDetails("Karthik");
		
		m1.printDetails("Banti", 28);
		
	}

}
