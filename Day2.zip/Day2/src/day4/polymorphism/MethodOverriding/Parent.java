package day4.polymorphism.MethodOverriding;

public class Parent {
	void displayResult() {
		System.out.println("This is from Parent Class");
	}
}
