package day4.polymorphism.MethodOverriding;

public class Child extends Parent {
	void displayResult() {
		System.out.println("This is form Child Class");
	}

}
