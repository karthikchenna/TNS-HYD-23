package day4.polymorphism.MethodOverriding;

public class Main {
	public static void main(String[] args) {
		Parent p1 = new Parent();
		p1.displayResult();
		
		Parent p2 = new  Child();
		p2.displayResult();
	}

}
