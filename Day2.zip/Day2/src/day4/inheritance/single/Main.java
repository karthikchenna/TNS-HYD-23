package day4.inheritance.single;

public class Main {

	public static void main(String[] args) {
		Child ch = new Child();
		ch.parent();
		ch.child();
	}

}
