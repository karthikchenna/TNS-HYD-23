package day4.inheritance.single;

public class Child extends Parent {
	void child() {
		System.out.println("Hello!, from Child Class");
	}
}
