package day4.inheritance.single;

public class Parent {
	void parent() {
		System.out.println("Hello!, from Parent Class");
	}
}
