package day4.inheritance.hybrid;

public class Main {

	public static void main(String[] args) {
		Child1 ch1 = new Child1();
		ch1.child1();
		ch1.childParent();
		ch1.parent();
		
		Child ch = new Child();
		ch.child();
		ch.childParent();
		ch.parent();

	}

}
