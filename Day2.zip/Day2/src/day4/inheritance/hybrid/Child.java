package day4.inheritance.hybrid;

public class Child extends ChildParent {
	void child() {
		System.out.println("Hello!, form Child");
	}
}
