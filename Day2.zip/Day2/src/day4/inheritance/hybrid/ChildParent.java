package day4.inheritance.hybrid;

public class ChildParent extends Parent {
	void childParent() {
		System.out.println("Hello!, from ChildParent Class");
	}

}
