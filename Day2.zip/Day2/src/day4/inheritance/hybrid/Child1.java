package day4.inheritance.hybrid;

public class Child1 extends ChildParent {
	void child1() {
		System.out.println("Hello!, from Child1");
	}
}
