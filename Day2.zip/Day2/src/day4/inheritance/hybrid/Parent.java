package day4.inheritance.hybrid;

public class Parent {
	void parent() {
		System.out.println("Hello from Parent");
	}
}
