package day4.inheritance.hierarchial;

public class Child1 extends Parent {
	void displayChild1() {
		System.out.println("Hello!, from Child1");
	}
}
