package day4.inheritance.hierarchial;

public class Child2 extends Parent {
	void displayChild2() {
		System.out.println("Hello!, from Child2");
	}
}
