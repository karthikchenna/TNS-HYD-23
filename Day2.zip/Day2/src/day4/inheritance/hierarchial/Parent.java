package day4.inheritance.hierarchial;

public class Parent {
	void printHello() {
		System.out.println("Hello!, from Parent Class");
	}
}
