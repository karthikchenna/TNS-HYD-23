package day4.inheritance.hierarchial;

public class Main {

	public static void main(String[] args) {
		Child1 ch1 = new Child1();
		ch1.printHello();
		ch1.displayChild1();
		
		Child2 ch2 = new Child2();
		ch2.printHello();
		ch2.displayChild2();
	}
	
}
