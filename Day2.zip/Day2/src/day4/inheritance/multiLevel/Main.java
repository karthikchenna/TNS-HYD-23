package day4.inheritance.multiLevel;

public class Main {

	public static void main(String[] args) {
		Child ch = new Child();
		ch.child();
		ch.childParent();
		ch.parent();
	}

}
