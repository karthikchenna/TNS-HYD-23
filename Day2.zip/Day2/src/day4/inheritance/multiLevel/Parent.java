package day4.inheritance.multiLevel;

public class Parent {
	void parent() {
		System.out.println("Hello!, from Parent Class");
	}
}
