package day4.inheritance.multiLevel;

public class ChildParent extends Parent {
	void childParent() {
		System.out.println("Hello!, from Child Parent Class");
	}
}
