package day4.inheritance.multiLevel;

public class Child extends ChildParent {
	void child() {
		System.out.println("Hello!, from Child Class");
	}
}
