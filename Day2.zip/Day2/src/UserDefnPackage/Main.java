package UserDefnPackage;
import pack.*;
import Subpackage.*;


public class Main {

	public static void main(String[] args) {
		A obj = new A();
		C obj1 = new C();
		D obj2 = new D();
		obj.msg();
		obj1.msg();
		obj2.msg();
		

	}

}
