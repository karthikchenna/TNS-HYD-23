package oop.Task1;

public class Task1Main {

	public static void main(String[] args) {
		Task1Normal n1 = new Task1Normal();
		
		n1.setSalary(52500);
		n1.printDivision();
		
		n1.setSalary(40060);
		n1.printDivision();
		
		n1.setSalary(37220);
		n1.printDivision();
		
		n1.setSalary(25500);
		n1.printDivision();


	}

}
