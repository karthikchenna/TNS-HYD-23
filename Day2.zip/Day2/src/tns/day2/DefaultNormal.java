package tns.day2;

public class DefaultNormal {
	String str = "This is a Default Member. This is accessible only within the package.";
}
