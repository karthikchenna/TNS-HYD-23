package tns.day2;

public class Approach2Main {

	public static void main(String[] args) {
		Approach2Base a1 = new Approach2Base();
		
		System.out.println(a1.a);
		a1.display();
		System.out.println(Approach2Base.b);
		Approach2Base.display1();

	}

}
