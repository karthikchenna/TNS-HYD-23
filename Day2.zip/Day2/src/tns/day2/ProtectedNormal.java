package tns.day2;

public class ProtectedNormal {
	protected String str = "This is a Protected member.";
	
	public static void main(String[] args) {
		ProtectedNormal n1 = new ProtectedNormal();
		
		System.out.println(n1.str);
	}

}
