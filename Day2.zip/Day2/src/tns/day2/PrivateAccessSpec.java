package tns.day2;

public class PrivateAccessSpec {
	private String str = "This is a Private Member!";
	
	public static void main(String[] args) {
		PrivateAccessSpec a1 = new PrivateAccessSpec();
		System.out.println(a1.str);
	}

}
