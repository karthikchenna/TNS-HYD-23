package Encapsulation;

public class EncapsulationNormal {
	private int noOfPalyers;
	private String isQualified;
	private String teamName;
	
	
	public int getNoOfPalyers() {
		return noOfPalyers;
	}


	public void setNoOfPalyers(int noOfPalyers) {
		this.noOfPalyers = noOfPalyers;
	}


	public String getIsQualified() {
		return isQualified;
	}


	public void setIsQualified(String isQualified) {
		this.isQualified = isQualified;
	}


	public String getTeamName() {
		return teamName;
	}


	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}


	public void winner() {
		if(noOfPalyers == 11 && isQualified.equals("True") && teamName.length() > 0) {
			System.out.println("You are the Winner");
		} else {
			System.out.println("You Lost the game");
		}
	}

}
