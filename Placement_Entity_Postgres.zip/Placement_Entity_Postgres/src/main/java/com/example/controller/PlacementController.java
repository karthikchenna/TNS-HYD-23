package com.example.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Placement;
import com.example.exception.ResourceNotFoundException;
import com.example.repository.PlacementRepository;

@RestController
@RequestMapping("/api/v1/")
public class PlacementController {
	
	@Autowired
	public PlacementRepository repository;
	
	@PostMapping("/placement")
	public Placement createPlacement(@RequestBody Placement placement) {
		return repository.save(placement);
	}
	
	@GetMapping("/placement")
	public List<Placement> getAllPlacement() {
		return repository.findAll();
	}
	
	@GetMapping("/placement/{id}")
	public ResponseEntity<Placement> getPlacementById(@PathVariable Long id) {
		Placement placement = repository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Placement not exist with id :" +id));
		return ResponseEntity.ok(placement);
	}
	
	@DeleteMapping("/placement/{id}")
	public ResponseEntity<Map<String, Boolean>> deletePlacement(@PathVariable Long id) {
		Placement placement = repository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Placement not exist with id :" +id));
		repository.delete(placement);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
	@PutMapping("/placement/{id}")
	public ResponseEntity<Placement> updatePlacement(@PathVariable Long id, @RequestBody Placement placementDetails) {
		Placement placement = repository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Placement not exist with id :" +id));
		placement.setName(placementDetails.getName());
		placement.setQualification(placementDetails.getQualification());
		placement.setYear(placementDetails.getYear());
		
		Placement updatePlacement = repository.save(placement);
		return ResponseEntity.ok(updatePlacement);
	}
}
